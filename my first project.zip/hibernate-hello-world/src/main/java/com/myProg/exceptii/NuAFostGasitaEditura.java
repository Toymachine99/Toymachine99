package com.myProg.exceptii;

public class NuAFostGasitaEditura extends RuntimeException{
    public NuAFostGasitaEditura(String message) {
        super(message);
    }
}
