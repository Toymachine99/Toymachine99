package com.myProg.exceptii;

public class NuAFostGasitaCartea extends RuntimeException{
    public NuAFostGasitaCartea(String text){
        super(text);
    }
}
